#ifndef _EXAMPLE_SPLIT_H_
#define _EXAMPLE_SPLIT_H_

#include "hls_video.h"

typedef ap_int<16>           INDEX_T;
typedef ap_fixed<12,6,AP_RND> COEF_T;
typedef hls::stream< ap_axiu<24,1,1,1> > AXI_STREAM;
typedef hls::Mat<720,1280, HLS_8UC3> RGB_IMAGE;
typedef hls::Mat<720,1280, HLS_8UC1> GRAY_IMAGE;

typedef ap_fixed<10,2, AP_RND, AP_SAT> coeff_type;

typedef hls::Scalar<1, unsigned char> GRAY_PIX;
typedef hls::Scalar<3, unsigned char> RGB_PIX;

#define INPUT_IMAGE		"E:/FPGAproject/GraySplit/graysplit/3.bmp"
#define OUTPUT_IMAGE 	"E:/FPGAproject/GraySplit/graysplit/3_out.bmp"

void img_defog(AXI_STREAM& input, AXI_STREAM& output, ap_uint<8> A);

#endif
