#include "E:/FPGAproject/GraySplit/HLS/img_defog.h"
#include "ap_int.h"
#include "ap_fixed.h"
#include "math.h"
/*
 * Slit function
 *
 * Splits an image into a RGB and a R part.
 *
 * int index:	col number where the split is
 */

void min_channel(
		RGB_IMAGE& img_in,
		GRAY_IMAGE& img_out) {

	RGB_PIX pin;
	//RGB_PIX pout;
	GRAY_PIX pdark;
//	unsigned char max = 255;
//	coeff_type w = 0.8;


L_row: for(int row = 0; row < 720; row++) {
#pragma HLS LOOP_TRIPCOUNT min=1 max=720

	L_col: for(int col = 0; col < 1280; col++) {
#pragma HLS LOOP_TRIPCOUNT min=1 max=1280
#pragma HLS loop_flatten off
#pragma HLS PIPELINE II = 1

           img_in >> pin;
           if(pin.val[0] < pin.val[1])
           {
        	   if(pin.val[0] < pin.val[2])
        	   {
        		   pdark.val[0] = pin.val[0];
//        		   pdark.val[1] = pin.val[0];
//        		   pdark.val[2] = pin.val[0];

        	   }
        	   else{
        		   pdark.val[0] = pin.val[2];
//        		   pdark.val[1] = pin.val[2];
//        		   pdark.val[2] = pin.val[2];

        	   }
           }
           else
           {
        	   if(pin.val[1] < pin.val[2])
        	   {
        		   pdark.val[0] = pin.val[1];
//        		   pdark.val[1] = pin.val[1];
//        		   pdark.val[2] = pin.val[1];

        	   }
        	   else
        	   {
        		   pdark.val[0] = pin.val[2];
//        		   pdark.val[1] = pin.val[2];
//        		   pdark.val[2] = pin.val[2];

        	   }
           }
//           pout.val[0] =( max -w*pdark.val[0]);
//           pout.val[0] = pdark.val[0];
          img_out << pdark;
        }


    }
}

void copy4(
		RGB_IMAGE& img_in,
		RGB_IMAGE& img_out1,
		RGB_IMAGE& img_out2,
		RGB_IMAGE& img_out3,
		RGB_IMAGE& img_out4)
{

	RGB_PIX pin;


L_row: for(int row = 0; row < 720; row++) {
#pragma HLS LOOP_TRIPCOUNT min=1 max=720

	L_col: for(int col = 0; col < 1280; col++) {
#pragma HLS LOOP_TRIPCOUNT min=1 max=1280
#pragma HLS loop_flatten off
#pragma HLS PIPELINE II = 1

		img_in >> pin;
		img_out1<<pin;
		img_out2<<pin;
		img_out3<<pin;
		img_out4<<pin;
		}

    }
}


void mysplit(
		RGB_IMAGE& img_in1,
		RGB_IMAGE& img_in2,
		RGB_IMAGE& img_out) {

	RGB_PIX pin1;
	RGB_PIX pin2;
	RGB_PIX pout;
	int a = 640, b = 1280, c = 0, d = 720;



L_row: for(int row = 0; row < 720; row++) {
#pragma HLS LOOP_TRIPCOUNT min=1 max=720

	L_col: for(int col = 0; col < 1280; col++) {
#pragma HLS LOOP_TRIPCOUNT min=1 max=1280
#pragma HLS loop_flatten off
#pragma HLS PIPELINE II = 1

           img_in1 >> pin1;
           img_in2 >> pin2;
           if(row > c && row < d)
           {
        	   if(col <= a || col >= b)
        	   {
        		   pout.val[0] = pin1.val[0];
        		   pout.val[1] = pin1.val[1];
        		   pout.val[2] = pin1.val[2];

        	   }
        	   else{
        		   pout.val[0] = pin2.val[0];
        		   pout.val[1] = pin2.val[1];
        		   pout.val[2] = pin2.val[2];

        	   }
           }
           else
           {
    		   pout.val[0] = pin1.val[0];
    		   pout.val[1] = pin1.val[1];
    		   pout.val[2] = pin1.val[2];

           }
//           pout.val[0] =( max -w*pdark.val[0]);
//           pout.val[0] = pdark.val[0];
          img_out << pout;
        }


    }
}

void getsinglechannel(
		RGB_IMAGE& img_in,
		GRAY_IMAGE& img_out1) {

	RGB_PIX pin;
	GRAY_PIX pout1;




L_row: for(int row = 0; row < 720; row++) {
#pragma HLS LOOP_TRIPCOUNT min=1 max=720

	L_col: for(int col = 0; col < 1280; col++) {
#pragma HLS LOOP_TRIPCOUNT min=1 max=1280
#pragma HLS loop_flatten off
#pragma HLS PIPELINE II = 1

           img_in >> pin;
          pout1.val[0] = pin.val[1] ;
       // pout2.val[0] = pin.val[2] ;
          img_out1 << pout1;
         // img_out2 << pout2;
        }


    }
}

void img_recover (RGB_IMAGE & img_rgb, GRAY_IMAGE & img_t, RGB_IMAGE & img_out, ap_uint<8> A)
{
	RGB_PIX pin1;
	GRAY_PIX pin2;
	RGB_PIX pout;
	ap_fixed<32,9,AP_RND_CONV,AP_SAT> temp;
//	ap_uint<8> A=250;
	ap_fixed<32,9,AP_RND_CONV,AP_SAT> temp1,temp2,temp3,temp4;

L_row: for(int row = 0; row < 720; row++) {
#pragma HLS LOOP_TRIPCOUNT min=1 max=720

	L_col: for(int col = 0; col < 1280; col++) {
#pragma HLS LOOP_TRIPCOUNT min=1 max=1280
#pragma HLS loop_flatten off
#pragma HLS PIPELINE II = 1

		   img_rgb >> pin1;
           img_t >> pin2;
           temp = pin2.val[0];
           temp1 = (temp + 1)/256;

           temp2 = (int(pin1.val[0])-A)/ temp1 + A ;
           temp3 = (int(pin1.val[1])-A)/ temp1 + A ;
           temp4 = (int(pin1.val[2])-A)/ temp1 + A ;
           pout.val[0] = temp2;
           pout.val[1] = temp3;
           pout.val[2] = temp4;
           img_out << pout;
        }
    }

}

void t_com(
		GRAY_IMAGE& img_in,
		GRAY_IMAGE& img_in2,
		GRAY_IMAGE& img_out,
		ap_uint<8> A)
{

	ap_ufixed<8,1,AP_RND_CONV,AP_SAT> w = 0.75;
	ap_ufixed<8,1,AP_RND_CONV,AP_SAT> thresold = 0.1;
	ap_fixed<32,16,AP_RND_CONV,AP_SAT> temp;

	ap_uint<1> max = 1;
	//ap_uint<8> A=250;
	GRAY_PIX pin,pin2;
	GRAY_PIX pt;
L_row1: for(int row = 0; row < 720; row++) {
#pragma HLS LOOP_TRIPCOUNT min=1 max=720

	L_col1: for(int col = 0; col < 1280; col++) {
#pragma HLS LOOP_TRIPCOUNT min=1 max=1280
#pragma HLS loop_flatten off
#pragma HLS PIPELINE II = 1
		img_in >> pin;
		img_in2 >> pin2;
		temp =1 - w * (pin2.val[0]+1)/256*pin.val[0] / A;
		if(temp > thresold)
			pt.val[0] = (temp << 8) - 1;
		else
			pt.val[0] = 26;
		img_out << pt;
		}
	}
}

void get_fix_C(
		GRAY_IMAGE& img_in1,
		//GRAY_IMAGE& img_in2,
		GRAY_IMAGE& img_out
		)
{

	//float s_temp = 0;

	//ap_ufixed<32,2,AP_RND_CONV,AP_SAT> s_C = 0;
	float v_temp = 0;
	ap_ufixed<32,9,AP_RND_CONV,AP_SAT> v_C = 0;
	//ap_ufixed<16,8,AP_RND_CONV,AP_SAT> v_k = 30.625;
	//float temp = 0;

	GRAY_PIX pin1,pin2,pout;
L_row1: for(int row = 0; row < 720; row++) {
#pragma HLS LOOP_TRIPCOUNT min=1 max=720

	L_col1: for(int col = 0; col < 1280; col++) {
#pragma HLS LOOP_TRIPCOUNT min=1 max=1280
#pragma HLS loop_flatten off
#pragma HLS PIPELINE II = 1
		img_in1 >> pin1;
		//img_in2 >> pin2;

		v_temp =((pin1.val[0] -240)*0.0333f);
		//s_temp = - pin2.val[0]*200;
		//s_C = 1/(1+hls::exp(s_temp));
		v_C = 1/(1+hls::exp(v_temp));

		pout.val[0] = v_C * 256 -1;

		img_out << pout;


		}
	}
}

void laplacian(GRAY_IMAGE& img_in, GRAY_IMAGE& img_out) {

	const COEF_T coef_v[3][3]= {
	  {-1,-1, -1},
	  {-1,8,-1},
	  {-1,-1,-1}
	};
	hls::Window<3,3,COEF_T> Sv;
	for (int r=0; r<3; r++) for (int c=0; c<3; c++) Sv.val[r][c] = coef_v[r][c];

	// point
	hls::Point_<INDEX_T> anchor;
	anchor.x=-1;
	anchor.y=-1;

	hls::Filter2D(img_in, img_out, Sv, anchor,0);
}


void get_dark(GRAY_IMAGE& img_in, GRAY_IMAGE& img_out)
{
	hls::Window<5 ,5 , ap_int<8> > filter1;

    hls::Point_<int> anchor1;
    anchor1.x = -1;
    anchor1.y = -1;
    hls::Filter2D(img_in, img_out, filter1, anchor1,3);

}

void get_V_max(GRAY_IMAGE& img_in, GRAY_IMAGE& img_out)
{
	hls::Window<5 ,5 , ap_int<8> > filter2;

    hls::Point_<int> anchor2;
    anchor2.x = -1;
    anchor2.y = -1;
	hls::Filter2D(img_in, img_out, filter2, anchor2,2);


}

void A_com(
		GRAY_IMAGE& img_in1,
		//GRAY_IMAGE& img_in2,
		ap_uint<8>& out
		)
{

	//float s_temp = 0;

	//ap_ufixed<32,2,AP_RND_CONV,AP_SAT> s_C = 0;
	ap_uint<8> max = 0;
	//ap_ufixed<16,8,AP_RND_CONV,AP_SAT> v_k = 30.625;
	//float temp = 0;

	GRAY_PIX pin;
L_row1: for(int row = 0; row < 720; row++) {
#pragma HLS LOOP_TRIPCOUNT min=1 max=720

	L_col1: for(int col = 0; col < 1280; col++) {
#pragma HLS LOOP_TRIPCOUNT min=1 max=1280
#pragma HLS loop_flatten off
#pragma HLS PIPELINE II = 1
		img_in1 >> pin;
		//img_in2 >> pin2;
		if(pin.val[0] > max)
			max = pin.val[0];
		}
	}

	out = max;
}

//void fix_t(
//		GRAY_IMAGE& img_in1,
//		GRAY_IMAGE& img_in2,
//		GRAY_IMAGE& img_out
//		)
//{
//
//	//float s_temp = 0;
//
//	//ap_ufixed<32,2,AP_RND_CONV,AP_SAT> s_C = 0;
//	float v_temp = 0;
//	ap_ufixed<32,9,AP_RND_CONV,AP_SAT> v_C = 0;
//	//ap_ufixed<16,8,AP_RND_CONV,AP_SAT> v_k = 30.625;
//	//float temp = 0;
//
//	GRAY_PIX pin1,pin2,pout;
//L_row1: for(int row = 0; row < 720; row++) {
//#pragma HLS LOOP_TRIPCOUNT min=1 max=720
//
//	L_col1: for(int col = 0; col < 1280; col++) {
//#pragma HLS LOOP_TRIPCOUNT min=1 max=1280
//#pragma HLS loop_flatten off
//#pragma HLS PIPELINE II = 1
//		img_in1 >> pin1;
//		//img_in2 >> pin2;
//
//		v_temp =((pin1.val[0] -240)*0.0333f);
//		//s_temp = - pin2.val[0]*200;
//		//s_C = 1/(1+hls::exp(s_temp));
//		v_C = 1/(1+hls::exp(v_temp));
//
//		pout.val[0] = v_C * 256 -1;
//
//		img_out << pout;
//
//
//		}
//	}
//}

//void min_3_3(
//		RGB_IMAGE& img_in,
//		RGB_IMAGE& img_out)
//{
//	RGB_PIX pin;
//	RGB_PIX pout;
//
//	hls::LineBuffer<3,1280,HLS_8UC3,0> buff_A;
//	hls::LineBuffer<3,1280,HLS_8UC3,0> aa;
//	hls::Window<3, 3, HLS_8UC3> mywindow ;
//	hls::Mat<720,1280,HLS_8UC3> xx;
//}

void img_defog(AXI_STREAM& in_data, AXI_STREAM& out_data,ap_uint<8> A) {

#pragma HLS INTERFACE axis register port=in_data
#pragma HLS INTERFACE axis register port=out_data

#pragma HLS INTERFACE ap_ctrl_none port=return
#pragma HLS INTERFACE s_axilite port=A
//#pragma HLS INTERFACE s_axilite port=b
//#pragma HLS INTERFACE s_axilite port=c
//#pragma HLS INTERFACE s_axilite port=d
#pragma HLS dataflow
	GRAY_IMAGE fix_C;
    RGB_IMAGE img_0;
    RGB_IMAGE img_1;
    RGB_IMAGE img_2;
    RGB_IMAGE img_3;
    RGB_IMAGE img_4;
    RGB_IMAGE img_5,img_ori,img_rec,img_sharping4,img_rec1,img_rec2,output_image_8U3;
    GRAY_IMAGE img_min,img_V,img_S,img_S_min,img_V_max;
    GRAY_IMAGE img_t,fix_t;
    GRAY_IMAGE img_dark,img_dark1,img_dark2,img_sharping1,img_sharping2,img_sharping3;
    RGB_IMAGE img_out;

   // hls::Filter2D(_src, _dst, _kernel, anchor)
//#pragma HLS stream depth=3600  variable=fix_C.data_stream
#pragma HLS stream depth=3600  variable=img_dark.data_stream
#pragma HLS stream depth=3600  variable=img_rec2.data_stream
#pragma HLS stream depth=7200  variable=img_3.data_stream
#pragma HLS stream depth=19200  variable=img_ori.data_stream
//#pragma HLS stream depth=128  variable=A.data_stream


	// Convert AXI4 Stream data to hls::mat format
	hls::AXIvideo2Mat(in_data, img_0);
	copy4(img_0,img_1,img_2,img_3,img_ori);
	//call the split function
	min_channel(img_1, img_min);
	//min_dark(img_dark,img_t);
	//hls::CvtColor<HLS_RGB2HSV>(img_5, img_3);
	getsinglechannel(img_2,img_V);
	//min_dark(img_dark,img_out);
	get_dark(img_min,img_dark);
	get_V_max(img_V, img_V_max);
	//hls::Duplicate(img_dark, img_dark1, img_dark2);

	//Convert the mat to Axi video stream
	get_fix_C(img_V_max,fix_C);
	//A_com(img_dark1,A);
	t_com(img_dark,fix_C,img_t,A);
	img_recover(img_3, img_t, img_rec,A);
	//hls::Filter2D(img_S, img_S_min, filter, anchor,1);
	hls::Duplicate(img_rec, img_rec1, img_rec2);
	//hls::CvtColor<HLS_GRAY2RGB>(img_dark, img_out);
	//hls::Filter2D(img_S, img_S_min, filter, anchor,1);

	hls::CvtColor<HLS_RGB2GRAY>(img_rec1, img_sharping1);
	laplacian(img_sharping1, img_sharping2);
	hls::Scale( img_sharping2, img_sharping3,0.1,0.0);
	hls::CvtColor<HLS_GRAY2RGB>(img_sharping3, img_sharping4);
	hls::AddWeighted(img_rec2, 1, img_sharping4, 1 , 0 , output_image_8U3);
	//fix_t(fix_C,img_t,fix_t);
	//hls::CvtColor<HLS_GRAY2RGB>(fix_C, img_out);
	mysplit(img_ori,output_image_8U3,img_out);
	//hls::Mat2AXIvideo(img_ori, out_data2);
	hls::Mat2AXIvideo(img_out, out_data);
}
